﻿namespace Data.Model
{
    public partial class ThongKeChiTiet : BaseModel
    {
        [Key]
        public long? ID { get; set; }
public long? ParentID { get; set; }
public string? ParentName { get; set; }
public DateTime? CreatedDate { get; set; }
public long? CreatedMembershipID { get; set; }
public DateTime? LastUpdatedDate { get; set; }
public long? LastUpdatedMembershipID { get; set; }
public int? RowVersion { get; set; }
public int? SortOrder { get; set; }
public bool? Active { get; set; }
public string? TypeName { get; set; }
public string? Name { get; set; }
public string? Code { get; set; }
public string? Note { get; set; }
public string? Display { get; set; }
public string? FileName { get; set; }
public string? Description { get; set; }
public string? HTMLContent { get; set; }
public long? DanhMucNgonNguID { get; set; }
public long? DanhMucUngDungID { get; set; }
public string? DanhMucNgonNguName { get; set; }
public string? DanhMucUngDungName { get; set; }
public string? Name001 { get; set; }
public string? Name002 { get; set; }
public string? Name003 { get; set; }
public string? Name004 { get; set; }
public string? Name005 { get; set; }
public string? Name006 { get; set; }
public string? Name007 { get; set; }
public string? Name008 { get; set; }
public string? Name009 { get; set; }
public string? Name010 { get; set; }
public string? Name011 { get; set; }
public string? Name012 { get; set; }
public int? Year { get; set; }
public int? Month { get; set; }
public int? Day { get; set; }
public int? Hour { get; set; }
public decimal? ThongKe001 { get; set; }
public decimal? ThongKe002 { get; set; }
public decimal? ThongKe003 { get; set; }
public decimal? ThongKe004 { get; set; }
public decimal? ThongKe005 { get; set; }
public decimal? ThongKe006 { get; set; }
public decimal? ThongKe007 { get; set; }
public decimal? ThongKe008 { get; set; }
public decimal? ThongKe009 { get; set; }
public decimal? ThongKe010 { get; set; }
public decimal? ThongKe011 { get; set; }
public decimal? ThongKe012 { get; set; }
public decimal? ThongKe013 { get; set; }
public decimal? ThongKe014 { get; set; }
public decimal? ThongKe015 { get; set; }
public decimal? ThongKe016 { get; set; }
public decimal? ThongKe017 { get; set; }
public decimal? ThongKe018 { get; set; }
public decimal? ThongKe019 { get; set; }
public decimal? ThongKe020 { get; set; }
public decimal? ThongKe021 { get; set; }
public decimal? ThongKe022 { get; set; }
public decimal? ThongKe023 { get; set; }
public decimal? ThongKe024 { get; set; }
public decimal? ThongKe025 { get; set; }
public decimal? ThongKe026 { get; set; }
public decimal? ThongKe027 { get; set; }
public decimal? ThongKe028 { get; set; }
public decimal? ThongKe029 { get; set; }
public decimal? ThongKe030 { get; set; }
public decimal? ThongKe031 { get; set; }

        public ThongKeChiTiet()
        {
        }
    }
}

