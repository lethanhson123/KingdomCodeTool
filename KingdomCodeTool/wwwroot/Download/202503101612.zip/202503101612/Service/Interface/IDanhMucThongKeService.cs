﻿namespace Service.Interface
{
    public interface IDanhMucThongKeService : IBaseService<DanhMucThongKe>
    {
    }
    }

