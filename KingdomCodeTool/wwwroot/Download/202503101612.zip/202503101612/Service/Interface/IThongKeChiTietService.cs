﻿namespace Service.Interface
{
    public interface IThongKeChiTietService : IBaseService<ThongKeChiTiet>
    {
    }
    }

