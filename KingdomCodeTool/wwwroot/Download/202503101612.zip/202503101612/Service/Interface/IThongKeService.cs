﻿namespace Service.Interface
{
    public interface IThongKeService : IBaseService<ThongKe>
    {
    }
    }

