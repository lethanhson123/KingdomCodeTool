﻿namespace Repository.Interface
{
    public interface IDanhMucThongKeRepository : IBaseRepository<DanhMucThongKe>
    {
    }
    }

