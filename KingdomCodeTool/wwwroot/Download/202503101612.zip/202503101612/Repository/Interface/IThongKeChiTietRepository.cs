﻿namespace Repository.Interface
{
    public interface IThongKeChiTietRepository : IBaseRepository<ThongKeChiTiet>
    {
    }
    }

