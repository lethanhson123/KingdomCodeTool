﻿namespace Repository.Interface
{
    public interface IThongKeRepository : IBaseRepository<ThongKe>
    {
    }
    }

