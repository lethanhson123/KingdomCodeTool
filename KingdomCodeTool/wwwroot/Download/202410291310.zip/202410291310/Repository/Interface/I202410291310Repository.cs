﻿namespace Repository.Interface
{
    public interface I202410291310Repository : IBaseRepository<202410291310>
    {
    }
    }

