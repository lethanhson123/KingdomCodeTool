﻿namespace Service.Interface
{
    public interface I202410291310Service : IBaseService<202410291310>
    {
    }
    }

