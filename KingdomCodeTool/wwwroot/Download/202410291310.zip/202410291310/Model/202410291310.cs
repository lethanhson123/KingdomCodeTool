﻿namespace Data.Model
{
    public partial class 202410291310 : BaseModel
    {
        
        public 202410291310()
        {
        }
    }
}

