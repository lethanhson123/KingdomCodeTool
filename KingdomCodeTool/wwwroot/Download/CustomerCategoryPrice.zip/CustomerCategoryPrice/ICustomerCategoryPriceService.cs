﻿namespace Business.Interface
{
    public interface ICustomerCategoryPriceService : IBaseService<CustomerCategoryPrice>
    {
    }
    }

