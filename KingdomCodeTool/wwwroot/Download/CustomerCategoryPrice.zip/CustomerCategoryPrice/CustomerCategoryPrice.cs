﻿namespace Data.Model
{
    public partial class CustomerCategoryPrice : BaseModel
    {
        public CustomerCategoryPrice()
        {
        }
    }
}

