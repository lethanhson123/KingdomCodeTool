﻿namespace Data.Repository.Interface
{
    public interface ICustomerCategoryPriceRepository : IBaseRepository<CustomerCategoryPrice>
    {
    }
    }

