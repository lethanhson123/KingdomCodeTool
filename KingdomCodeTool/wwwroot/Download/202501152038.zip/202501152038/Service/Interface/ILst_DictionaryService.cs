﻿namespace Service.Interface
{
    public interface ILst_DictionaryService : IBaseService<Lst_Dictionary>
    {
    }
    }

