﻿namespace Repository.Interface
{
    public interface ILst_DictionaryRepository : IBaseRepository<Lst_Dictionary>
    {
    }
    }

