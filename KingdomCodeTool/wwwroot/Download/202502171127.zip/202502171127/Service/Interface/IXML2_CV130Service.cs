﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML2_CV130Service : IBaseService<XML2_CV130>
    {
    }
    }

