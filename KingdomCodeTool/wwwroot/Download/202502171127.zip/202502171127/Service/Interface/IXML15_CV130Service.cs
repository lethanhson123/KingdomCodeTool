﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML15_CV130Service : IBaseService<XML15_CV130>
    {
    }
    }

