﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML12_CV130Service : IBaseService<XML12_CV130>
    {
    }
    }

