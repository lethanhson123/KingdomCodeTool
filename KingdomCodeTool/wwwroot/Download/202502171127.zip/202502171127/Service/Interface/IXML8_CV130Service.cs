﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML8_CV130Service : IBaseService<XML8_CV130>
    {
    }
    }

