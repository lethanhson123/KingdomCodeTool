﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML4_CV130Service : IBaseService<XML4_CV130>
    {
    }
    }

