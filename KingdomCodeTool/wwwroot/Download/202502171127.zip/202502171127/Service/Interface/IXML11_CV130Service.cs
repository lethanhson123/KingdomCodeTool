﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML11_CV130Service : IBaseService<XML11_CV130>
    {
    }
    }

