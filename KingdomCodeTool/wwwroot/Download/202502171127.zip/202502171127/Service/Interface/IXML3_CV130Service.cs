﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML3_CV130Service : IBaseService<XML3_CV130>
    {
    }
    }

