﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML6_CV130Service : IBaseService<XML6_CV130>
    {
    }
    }

