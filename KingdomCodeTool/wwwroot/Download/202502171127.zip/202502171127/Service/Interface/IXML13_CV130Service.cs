﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML13_CV130Service : IBaseService<XML13_CV130>
    {
    }
    }

