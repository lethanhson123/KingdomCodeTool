﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML1_CV130Service : IBaseService<XML1_CV130>
    {
    }
    }

