﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML7_CV130Service : IBaseService<XML7_CV130>
    {
    }
    }

