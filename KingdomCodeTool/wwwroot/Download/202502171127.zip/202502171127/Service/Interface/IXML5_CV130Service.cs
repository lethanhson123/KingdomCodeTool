﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IXML5_CV130Service : IBaseService<XML5_CV130>
    {
    }
    }

