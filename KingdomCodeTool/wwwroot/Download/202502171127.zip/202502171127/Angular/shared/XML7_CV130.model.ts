﻿import { Base } from "./Base.model";

export class XML7_CV130 extends Base{
XML7_CV130_Id?: number;
BenhAn_Id?: number;
TiepNhan_Id?: number;
BenhNhan_Id?: number;
XacNhanChiPhi_Id?: number;
MA_LK?: string;
SO_LUU_TRU?: string;
MA_YTE?: string;
MA_KHOA_RV?: string;
NGAY_VAO?: string;
NGAY_RA?: string;
MA_DINH_CHI_THAI?: number;
NGUYENNHAN_DINHCHI?: string;
THOIGIAN_DINHCHI?: string;
TUOI_THAI?: number;
CHAN_DOAN_RV?: string;
PP_DIEUTRI?: string;
GHI_CHU?: string;
MA_TTDV?: string;
MA_BS?: string;
TEN_BS?: string;
NGAY_CT?: string;
MA_CHA?: string;
MA_ME?: string;
MA_THE_TAM?: string;
HO_TEN_CHA?: string;
HO_TEN_ME?: string;
SO_NGAY_NGHI?: number;
NGOAITRU_TUNGAY?: string;
NGOAITRU_DENNGAY?: string;

}


