﻿import { Base } from "./Base.model";

export class XML4_CV130 extends Base{
XML4_CV130_Id?: number;
BenhAn_Id?: number;
TiepNhan_Id?: number;
BenhNhan_Id?: number;
XacNhanChiPhi_Id?: number;
MA_LK?: string;
STT?: number;
MA_DICH_VU?: string;
MA_CHI_SO?: string;
TEN_CHI_SO?: string;
GIA_TRI?: string;
DON_VI_DO?: string;
MO_TA?: string;
KET_LUAN?: string;
NGAY_KQ?: string;
MA_BS_DOC_KQ?: string;
DU_PHONG?: string;

}


