﻿import { Base } from "./Base.model";

export class XML15_CV130 extends Base{
XML15_CV130_Id?: number;
BenhAn_Id?: number;
TiepNhan_Id?: number;
BenhNhan_Id?: number;
XacNhanChiPhi_Id?: number;
MA_LK?: string;
STT?: number;
MA_BN?: string;
HO_TEN?: string;
SO_CCCD?: string;
PHANLOAI_LAO_VITRI?: number;
PHANLOAI_LAO_TS?: number;
PHANLOAI_LAO_HIV?: number;
PHANLOAI_LAO_VK?: number;
PHANLOAI_LAO_KT?: number;
LOAI_DTRI_LAO?: number;
NGAYBD_DTRI_LAO?: string;
PHACDO_DTRI_LAO?: number;
NGAYKT_DTRI_LAO?: string;
KET_QUA_DTRI_LAO?: number;
MA_CSKCB?: string;
NGAYKD_HIV?: string;
BDDT_ARV?: string;
NGAY_BAT_DAU_DT_CTX?: string;
DU_PHONG?: string;

}


