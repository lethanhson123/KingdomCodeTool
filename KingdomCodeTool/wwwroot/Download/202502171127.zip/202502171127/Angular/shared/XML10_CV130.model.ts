﻿import { Base } from "./Base.model";

export class XML10_CV130 extends Base{
XML10_CV130_Id?: number;
BenhAn_Id?: number;
TiepNhan_Id?: number;
BenhNhan_Id?: number;
XacNhanChiPhi_Id?: number;
MA_LK?: string;
SO_SERI?: string;
SO_CT?: string;
SO_NGAY?: number;
DON_VI?: string;
CHAN_DOAN_RV?: string;
TU_NGAY?: string;
DEN_NGAY?: string;
MA_TTDV?: string;
TEN_BS?: string;
MA_BS?: string;
NGAY_CT?: string;

}


