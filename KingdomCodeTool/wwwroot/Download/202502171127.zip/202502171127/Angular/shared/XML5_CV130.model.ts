﻿import { Base } from "./Base.model";

export class XML5_CV130 extends Base{
XML5_CV130_Id?: number;
BenhAn_Id?: number;
TiepNhan_Id?: number;
BenhNhan_Id?: number;
XacNhanChiPhi_Id?: number;
MA_LK?: string;
STT?: number;
DIEN_BIEN_LS?: string;
GIAI_DOAN_BENH?: string;
HOI_CHAN?: string;
PHAU_THUAT?: string;
THOI_DIEM_DBLS?: string;
NGUOI_THUC_HIEN?: string;
DU_PHONG?: string;

}


