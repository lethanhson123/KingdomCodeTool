﻿import { Base } from "./Base.model";

export class XML14_CV130 extends Base{
XML14_CV130_Id?: number;
BenhAn_Id?: number;
TiepNhan_Id?: number;
BenhNhan_Id?: number;
XacNhanChiPhi_Id?: number;
MA_LK?: string;
SO_GIAYHEN_KL?: string;
MA_CSKCB?: string;
HO_TEN?: string;
NGAY_SINH?: string;
GIOI_TINH?: number;
DIA_CHI?: string;
MA_THE_BHYT?: string;
GT_THE_DEN?: string;
NGAY_VAO?: string;
NGAY_VAO_NOI_TRU?: string;
NGAY_RA?: string;
NGAY_HEN_KL?: string;
CHAN_DOAN_RV?: string;
MA_BENH_CHINH?: string;
MA_BENH_KT?: string;
MA_BENH_YHCT?: string;
MA_DOITUONG_KCB?: string;
MA_BAC_SI?: string;
MA_TTDV?: string;
NGAY_CT?: string;
DU_PHONG?: string;

}


