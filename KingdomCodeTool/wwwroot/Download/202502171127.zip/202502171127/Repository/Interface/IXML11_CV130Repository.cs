﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML11_CV130Repository : IBaseRepository<XML11_CV130>
    {
    }
    }

