﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML4_CV130Repository : IBaseRepository<XML4_CV130>
    {
    }
    }

