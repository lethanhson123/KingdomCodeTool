﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML3_CV130Repository : IBaseRepository<XML3_CV130>
    {
    }
    }

