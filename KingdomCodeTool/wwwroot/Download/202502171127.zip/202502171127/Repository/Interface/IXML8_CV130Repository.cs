﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML8_CV130Repository : IBaseRepository<XML8_CV130>
    {
    }
    }

