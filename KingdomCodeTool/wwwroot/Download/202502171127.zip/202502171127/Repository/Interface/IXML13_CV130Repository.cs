﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML13_CV130Repository : IBaseRepository<XML13_CV130>
    {
    }
    }

