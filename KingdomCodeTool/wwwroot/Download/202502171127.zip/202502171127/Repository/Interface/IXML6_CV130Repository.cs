﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML6_CV130Repository : IBaseRepository<XML6_CV130>
    {
    }
    }

