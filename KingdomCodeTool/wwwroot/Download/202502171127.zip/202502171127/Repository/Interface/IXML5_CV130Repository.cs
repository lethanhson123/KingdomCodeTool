﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML5_CV130Repository : IBaseRepository<XML5_CV130>
    {
    }
    }

