﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML1_CV130Repository : IBaseRepository<XML1_CV130>
    {
    }
    }

