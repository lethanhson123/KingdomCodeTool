﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML15_CV130Repository : IBaseRepository<XML15_CV130>
    {
    }
    }

