﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML12_CV130Repository : IBaseRepository<XML12_CV130>
    {
    }
    }

