﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML2_CV130Repository : IBaseRepository<XML2_CV130>
    {
    }
    }

