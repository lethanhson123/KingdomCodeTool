﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML14_CV130Repository : IBaseRepository<XML14_CV130>
    {
    }
    }

