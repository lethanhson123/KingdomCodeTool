﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IXML7_CV130Repository : IBaseRepository<XML7_CV130>
    {
    }
    }

