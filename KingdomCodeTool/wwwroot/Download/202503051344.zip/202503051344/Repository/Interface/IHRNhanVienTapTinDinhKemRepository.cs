﻿namespace Repository.Interface
{
    public interface IHRNhanVienTapTinDinhKemRepository : IBaseRepository<HRNhanVienTapTinDinhKem>
    {
    }
    }

