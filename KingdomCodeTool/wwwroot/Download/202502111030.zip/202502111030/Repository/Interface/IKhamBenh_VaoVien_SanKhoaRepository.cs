﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IKhamBenh_VaoVien_SanKhoaRepository : IBaseRepository<KhamBenh_VaoVien_SanKhoa>
    {
    }
    }

