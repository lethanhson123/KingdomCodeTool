﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IKhamBenh_VaoVienService : IBaseService<KhamBenh_VaoVien>
    {
    }
    }

