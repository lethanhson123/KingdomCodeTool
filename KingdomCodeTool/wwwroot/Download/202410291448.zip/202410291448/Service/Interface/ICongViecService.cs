﻿namespace Service.Interface
{
    public interface ICongViecService : IBaseService<CongViec>
    {
    }
    }

