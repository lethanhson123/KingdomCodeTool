﻿namespace Data.Model
{
    public partial class CustomerCategory : BaseModel
    {
        public CustomerCategory()
        {
        }
    }
}

