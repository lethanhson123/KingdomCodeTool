﻿namespace Business.Interface
{
    public interface ICustomerCategoryService : IBaseService<CustomerCategory>
    {
    }
    }

