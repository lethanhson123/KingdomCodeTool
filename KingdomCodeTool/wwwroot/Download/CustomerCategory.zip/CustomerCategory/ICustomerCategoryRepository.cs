﻿namespace Data.Repository.Interface
{
    public interface ICustomerCategoryRepository : IBaseRepository<CustomerCategory>
    {
    }
    }

