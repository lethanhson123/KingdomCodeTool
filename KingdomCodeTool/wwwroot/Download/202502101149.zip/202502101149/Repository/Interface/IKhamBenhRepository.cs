﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IKhamBenhRepository : IBaseRepository<KhamBenh>
    {
    }
    }

