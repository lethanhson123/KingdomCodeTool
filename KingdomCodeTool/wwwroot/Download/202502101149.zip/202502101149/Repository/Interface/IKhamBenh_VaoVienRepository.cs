﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IKhamBenh_VaoVienRepository : IBaseRepository<KhamBenh_VaoVien>
    {
    }
    }

