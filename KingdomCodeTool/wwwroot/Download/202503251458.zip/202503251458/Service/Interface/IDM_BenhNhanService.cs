﻿namespace Service_eHospital_DongNai_A_Dictionary.Interface
{
    public interface IDM_BenhNhanService : IBaseService<DM_BenhNhan>
    {
    }
    }

