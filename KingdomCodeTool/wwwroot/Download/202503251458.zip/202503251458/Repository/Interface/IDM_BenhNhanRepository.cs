﻿namespace Repository_eHospital_DongNai_A_Dictionary.Interface
{
    public interface IDM_BenhNhanRepository : IBaseRepository<DM_BenhNhan>
    {
    }
    }

