﻿namespace Data.Repository.Interface
{
    public interface ICustomerWishlistRepository : IBaseRepository<CustomerWishlist>
    {
    }
    }

