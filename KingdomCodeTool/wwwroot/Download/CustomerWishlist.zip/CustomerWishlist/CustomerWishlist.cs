﻿namespace Data.Model
{
    public partial class CustomerWishlist : BaseModel
    {
        public CustomerWishlist()
        {
        }
    }
}

