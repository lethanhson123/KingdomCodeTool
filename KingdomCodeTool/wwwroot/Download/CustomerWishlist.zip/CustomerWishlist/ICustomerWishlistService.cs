﻿namespace Business.Interface
{
    public interface ICustomerWishlistService : IBaseService<CustomerWishlist>
    {
    }
    }

