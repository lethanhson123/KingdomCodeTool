﻿namespace Service_eHospital_DongNai_A_Config.Interface
{
    public interface ISys_AppPrivateSettingsService : IBaseService<Sys_AppPrivateSettings>
    {
    }
    }

