﻿namespace Service_eHospital_DongNai_A_Config.Interface
{
    public interface ISys_AppSettingsService : IBaseService<Sys_AppSettings>
    {
    }
    }

