﻿namespace Repository_eHospital_DongNai_A_Config.Interface
{
    public interface ISys_AppSettingsRepository : IBaseRepository<Sys_AppSettings>
    {
    }
    }

