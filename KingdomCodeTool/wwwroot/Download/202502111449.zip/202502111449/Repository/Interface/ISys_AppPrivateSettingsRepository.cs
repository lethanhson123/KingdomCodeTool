﻿namespace Repository_eHospital_DongNai_A_Config.Interface
{
    public interface ISys_AppPrivateSettingsRepository : IBaseRepository<Sys_AppPrivateSettings>
    {
    }
    }

