﻿import { Base } from "./Base.model";

export class Sys_AppPrivateSettings extends Base{
Setting_Id?: number;
Group_Code?: string;
Code?: string;
User_Id?: number;
Computer?: string;
Value?: string;
Description?: string;
CreationDate?: Date;
CreatedBy?: number;
LastUpdateDate?: Date;
LastUpdatedBy?: number;

}


