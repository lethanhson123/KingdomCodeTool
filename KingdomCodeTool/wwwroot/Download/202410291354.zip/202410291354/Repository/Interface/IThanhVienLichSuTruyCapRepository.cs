﻿namespace Repository.Interface
{
    public interface IThanhVienLichSuTruyCapRepository : IBaseRepository<ThanhVienLichSuTruyCap>
    {
    }
    }

