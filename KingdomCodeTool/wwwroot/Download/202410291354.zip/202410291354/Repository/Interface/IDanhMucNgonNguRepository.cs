﻿namespace Repository.Interface
{
    public interface IDanhMucNgonNguRepository : IBaseRepository<DanhMucNgonNgu>
    {
    }
    }

