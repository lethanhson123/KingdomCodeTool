﻿namespace Repository.Interface
{
    public interface IDanhMucChucDanhRepository : IBaseRepository<DanhMucChucDanh>
    {
    }
    }

