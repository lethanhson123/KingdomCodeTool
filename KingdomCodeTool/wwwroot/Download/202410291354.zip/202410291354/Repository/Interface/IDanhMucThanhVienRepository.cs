﻿namespace Repository.Interface
{
    public interface IDanhMucThanhVienRepository : IBaseRepository<DanhMucThanhVien>
    {
    }
    }

