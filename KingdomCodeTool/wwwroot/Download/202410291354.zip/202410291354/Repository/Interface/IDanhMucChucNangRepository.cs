﻿namespace Repository.Interface
{
    public interface IDanhMucChucNangRepository : IBaseRepository<DanhMucChucNang>
    {
    }
    }

