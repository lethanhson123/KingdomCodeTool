﻿namespace Repository.Interface
{
    public interface IDanhMucPhongBanRepository : IBaseRepository<DanhMucPhongBan>
    {
    }
    }

