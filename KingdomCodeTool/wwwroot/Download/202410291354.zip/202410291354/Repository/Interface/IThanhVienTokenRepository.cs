﻿namespace Repository.Interface
{
    public interface IThanhVienTokenRepository : IBaseRepository<ThanhVienToken>
    {
    }
    }

