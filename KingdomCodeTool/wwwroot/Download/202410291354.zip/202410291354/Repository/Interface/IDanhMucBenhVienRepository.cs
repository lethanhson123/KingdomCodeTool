﻿namespace Repository.Interface
{
    public interface IDanhMucBenhVienRepository : IBaseRepository<DanhMucBenhVien>
    {
    }
    }

