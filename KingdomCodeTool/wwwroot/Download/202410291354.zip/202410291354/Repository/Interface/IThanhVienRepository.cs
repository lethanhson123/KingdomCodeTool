﻿namespace Repository.Interface
{
    public interface IThanhVienRepository : IBaseRepository<ThanhVien>
    {
    }
    }

