﻿namespace Repository.Interface
{
    public interface IThanhVienChucNangRepository : IBaseRepository<ThanhVienChucNang>
    {
    }
    }

