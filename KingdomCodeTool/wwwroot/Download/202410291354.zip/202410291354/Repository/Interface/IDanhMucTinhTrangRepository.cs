﻿namespace Repository.Interface
{
    public interface IDanhMucTinhTrangRepository : IBaseRepository<DanhMucTinhTrang>
    {
    }
    }

