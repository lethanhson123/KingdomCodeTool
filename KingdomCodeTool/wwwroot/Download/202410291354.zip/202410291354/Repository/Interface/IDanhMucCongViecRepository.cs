﻿namespace Repository.Interface
{
    public interface IDanhMucCongViecRepository : IBaseRepository<DanhMucCongViec>
    {
    }
    }

