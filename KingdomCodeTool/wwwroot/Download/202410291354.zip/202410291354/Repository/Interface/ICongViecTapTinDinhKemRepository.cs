﻿namespace Repository.Interface
{
    public interface ICongViecTapTinDinhKemRepository : IBaseRepository<CongViecTapTinDinhKem>
    {
    }
    }

