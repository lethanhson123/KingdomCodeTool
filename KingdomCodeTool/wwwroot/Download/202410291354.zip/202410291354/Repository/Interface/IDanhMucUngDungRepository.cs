﻿namespace Repository.Interface
{
    public interface IDanhMucUngDungRepository : IBaseRepository<DanhMucUngDung>
    {
    }
    }

