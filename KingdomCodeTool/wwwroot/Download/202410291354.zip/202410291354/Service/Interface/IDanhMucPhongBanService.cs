﻿namespace Service.Interface
{
    public interface IDanhMucPhongBanService : IBaseService<DanhMucPhongBan>
    {
    }
    }

