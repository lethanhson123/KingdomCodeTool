﻿namespace Service.Interface
{
    public interface IDanhMucBenhVienService : IBaseService<DanhMucBenhVien>
    {
    }
    }

