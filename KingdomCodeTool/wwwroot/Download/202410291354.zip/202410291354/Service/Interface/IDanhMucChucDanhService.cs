﻿namespace Service.Interface
{
    public interface IDanhMucChucDanhService : IBaseService<DanhMucChucDanh>
    {
    }
    }

