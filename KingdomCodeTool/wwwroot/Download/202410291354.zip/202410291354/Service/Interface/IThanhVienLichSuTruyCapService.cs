﻿namespace Service.Interface
{
    public interface IThanhVienLichSuTruyCapService : IBaseService<ThanhVienLichSuTruyCap>
    {
    }
    }

