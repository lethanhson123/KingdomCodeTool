﻿namespace Service.Interface
{
    public interface IThanhVienTokenService : IBaseService<ThanhVienToken>
    {
    }
    }

