﻿namespace Service.Interface
{
    public interface IDanhMucChucNangService : IBaseService<DanhMucChucNang>
    {
    }
    }

