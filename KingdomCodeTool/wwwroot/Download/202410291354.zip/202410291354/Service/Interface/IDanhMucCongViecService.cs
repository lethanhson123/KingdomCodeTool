﻿namespace Service.Interface
{
    public interface IDanhMucCongViecService : IBaseService<DanhMucCongViec>
    {
    }
    }

