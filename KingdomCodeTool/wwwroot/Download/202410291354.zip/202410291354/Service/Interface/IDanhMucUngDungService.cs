﻿namespace Service.Interface
{
    public interface IDanhMucUngDungService : IBaseService<DanhMucUngDung>
    {
    }
    }

