﻿namespace Service.Interface
{
    public interface IThanhVienChucNangService : IBaseService<ThanhVienChucNang>
    {
    }
    }

