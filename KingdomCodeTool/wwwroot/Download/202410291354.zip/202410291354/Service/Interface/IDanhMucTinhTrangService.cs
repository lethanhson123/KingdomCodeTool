﻿namespace Service.Interface
{
    public interface IDanhMucTinhTrangService : IBaseService<DanhMucTinhTrang>
    {
    }
    }

