﻿namespace Service.Interface
{
    public interface IThanhVienService : IBaseService<ThanhVien>
    {
    }
    }

