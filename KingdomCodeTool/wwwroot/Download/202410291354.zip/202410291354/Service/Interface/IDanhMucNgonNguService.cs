﻿namespace Service.Interface
{
    public interface IDanhMucNgonNguService : IBaseService<DanhMucNgonNgu>
    {
    }
    }

