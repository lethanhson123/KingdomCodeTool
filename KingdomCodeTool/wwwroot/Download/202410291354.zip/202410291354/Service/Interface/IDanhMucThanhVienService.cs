﻿namespace Service.Interface
{
    public interface IDanhMucThanhVienService : IBaseService<DanhMucThanhVien>
    {
    }
    }

