﻿namespace Service.Interface
{
    public interface ICongViecTapTinDinhKemService : IBaseService<CongViecTapTinDinhKem>
    {
    }
    }

