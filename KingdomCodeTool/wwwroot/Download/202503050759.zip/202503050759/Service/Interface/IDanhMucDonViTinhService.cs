﻿namespace Service.Interface
{
    public interface IDanhMucDonViTinhService : IBaseService<DanhMucDonViTinh>
    {
    }
    }

