﻿namespace Service.Interface
{
    public interface IDanhMucMayChamCongService : IBaseService<DanhMucMayChamCong>
    {
    }
    }

