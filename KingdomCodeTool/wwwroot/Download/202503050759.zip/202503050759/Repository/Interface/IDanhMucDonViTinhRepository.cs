﻿namespace Repository.Interface
{
    public interface IDanhMucDonViTinhRepository : IBaseRepository<DanhMucDonViTinh>
    {
    }
    }

