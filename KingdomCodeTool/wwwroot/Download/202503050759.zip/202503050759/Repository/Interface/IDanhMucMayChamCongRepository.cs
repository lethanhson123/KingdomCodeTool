﻿namespace Repository.Interface
{
    public interface IDanhMucMayChamCongRepository : IBaseRepository<DanhMucMayChamCong>
    {
    }
    }

