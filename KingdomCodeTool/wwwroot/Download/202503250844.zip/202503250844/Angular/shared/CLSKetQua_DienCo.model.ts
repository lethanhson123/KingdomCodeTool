﻿import { Base } from "./Base.model";

export class CLSKetQua_DienCo extends Base{
CLSKetQua_DienCo_Id?: number;
CLSKetQua_Id?: number;
MauBenh_Id?: number;
Col_Int_1?: number;
Col_Int_2?: number;
Col_Int_3?: number;
Col_Int_4?: number;
Col_Int_5?: number;
Col_Int_6?: number;
Col_Int_7?: number;
Col_Int_8?: number;
Col_Int_9?: number;
Col_Int_10?: number;
Col_Text_1?: string;
Col_Text_2?: string;
Col_Text_3?: string;
Col_Text_4?: string;
Col_Text_5?: string;
Col_Text_6?: string;
Col_Text_7?: string;
Col_Text_8?: string;
Col_Text_9?: string;
Col_Text_10?: string;
Col_DateTime_1?: Date;
Col_DateTime_2?: Date;
Col_DateTime_3?: Date;
Col_DateTime_4?: Date;
Col_DateTime_5?: Date;
Col_DateTime_6?: Date;
Col_DateTime_7?: Date;
Col_DateTime_8?: Date;
Col_DateTime_9?: Date;
Col_DateTime_10?: Date;
HienThi?: boolean;
Ma_MauBenh_Column?: string;
Idx?: number;
Col_Decimal_1?: number;
Col_Decimal_2?: number;
Col_Decimal_3?: number;
Col_Decimal_4?: number;
Col_Decimal_5?: number;
Col_Decimal_6?: number;
Col_Decimal_7?: number;
Col_Decimal_8?: number;
Col_Decimal_9?: number;
Col_Decimal_10?: number;
KetQuaMauBenh_Id?: number;
TemplateFileName?: string;

}


