﻿import { Base } from "./Base.model";

export class CLSKetQuaKhangSinhDo extends Base{
KetQuaKhangSinhDo_Id?: number;
CLSKetQua_Id?: number;
KhangSinhDo_Id?: number;
NhomKhangSinhDo_Id?: number;
TenNguonXetNghiem?: string;
KetQua?: string;
KhangSinhDo?: boolean;
TenKetQua?: string;
CapTren_Id?: number;
InstrMIC?: string;
FinalSIR?: string;
Rules?: string;

}


