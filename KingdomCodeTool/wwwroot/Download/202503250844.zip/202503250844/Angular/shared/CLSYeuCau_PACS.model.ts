﻿import { Base } from "./Base.model";

export class CLSYeuCau_PACS extends Base{
PACS_ID?: number;
CLSYeuCau_ID?: number;

}


