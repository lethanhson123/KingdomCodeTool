﻿import { Base } from "./Base.model";

export class NoiTru_LuuTruChiTiet extends Base{
LuuTruChiTiet_Id?: number;
LuuTru_Id?: number;
PhongBan_Id?: number;
GiuongBenh_Id?: number;
PhongBenh_Id?: number;
NgayVao?: Date;
ThoiGianVao?: Date;
ThoiGianTinhLuuTru?: Date;
LyDo_Id?: number;
NgayRa?: Date;
ThoiGianRa?: Date;
DonGiaPhaiThu?: string;
DonGia?: string;
TyLeVAT?: string;
GiaTriVAT?: string;
TienTe_Id?: string;
Tygia?: string;
LoaiGia_Id?: number;
GiuongBenhChuyenDen_Id?: number;
BaoPhong?: boolean;
KhongTinhTien?: boolean;
NgayTao?: Date;
NguoiTao_Id?: number;
NgayCapNhat?: Date;
NguoiCapNhat_Id?: number;
LuuTruChiTiet_Prev?: number;
LuuTruChiTiet_Current?: boolean;
DoiTuong_Id?: number;
LuuTruChiTiet_Id_Last?: boolean;
SiteCode?: string;
Mapping_Public_Id?: number;

}


