﻿import { Base } from "./Base.model";

export class NoiTru_TraThuoc extends Base{
NoiTru_TraThuoc_Id?: number;
SoPhieu?: string;
BenhAn_Id?: number;
LuuTru_Id?: number;
NgayTra?: Date;
NguoiNhan_Id?: number;
GhiChu?: string;
TrangThai?: string;
NgayTao?: Date;
NguoiTao_Id?: number;
NgayCapNhat?: Date;
NguoiCapNhat_Id?: number;
DienGiaiNghiepVuPhatSinh?: string;
ThoiGianTra?: Date;
ChungTu_Id?: number;

}


