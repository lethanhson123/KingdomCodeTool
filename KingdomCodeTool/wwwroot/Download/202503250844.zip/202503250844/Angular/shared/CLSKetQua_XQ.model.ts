﻿import { Base } from "./Base.model";

export class CLSKetQua_XQ extends Base{
CLSKetQua_XQ_Id?: number;
SoPhieu?: string;
CLSYeuCau_Id?: number;
ID_CT?: string;

}


