﻿import { Base } from "./Base.model";

export class NoiTru_TraThuocChiTiet extends Base{
NoiTru_TraThuocChiTiet_Id?: number;
NoiTru_TraThuoc_Id?: number;
ToaThuoc_Id?: number;
Duoc_Id?: number;
SoLuong?: string;
TyLeVAT?: string;
GiaTriVAT?: string;
TyGia?: string;
DonGiaDoanhThu?: string;
DonGiaHoTro?: string;
DonGiaHoTroChiTra?: string;
DonGiaThanhToan?: string;
DaHoanTra?: boolean;
ChungTuTra_Id?: number;
TienTe_Id?: string;
ChungTuChiTiet_Id?: number;
LoaiGia_Id?: number;

}


