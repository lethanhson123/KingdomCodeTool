﻿import { Base } from "./Base.model";

export class CLSKetQua_Images extends Base{
Images_Id?: number;
CLSKetQua_Id?: number;
File_Name_Origin?: string;
File_Name?: string;
Idx?: number;
TenHinh?: string;
MoTaHinh?: string;
TamNgung?: boolean;
NgayTao?: Date;
NguoiTao_Id?: number;
NgayCapNhat?: Date;
NguoiCapNhat_Id?: number;
ChonInMacDinh?: boolean;

}


