﻿import { Base } from "./Base.model";

export class CLSYeuCau_QMS extends Base{
CLSYeuCau_Id?: number;
SoTT?: number;
HangDoi_Idx?: number;
HangDoi_Details?: number;
KhuVuc?: string;
App?: boolean;

}


