﻿import { Base } from "./Base.model";

export class KhamBenh_SinhHieu extends Base{
BenhNhan_Id?: number;
Mach?: number;
HuyetApThap?: number;
HuyetApCao?: number;
NhipTho?: number;
NhietDo?: number;
ChieuCao?: number;
CanNang?: number;
BMI?: number;

}


