﻿import { Base } from "./Base.model";

export class CLSYeuCau_ThayDoi extends Base{
CLSYeuCau_ThayDoi_Id?: number;
CLSYeuCau_Id?: number;
PhongBan_Id?: number;
PhongBan_ThayDoi_Id?: number;
LanThayDoi?: number;
NgayThayDoi?: Date;
ThoiGianThayDoi?: Date;
NguoiThayDoi_Id?: number;
NgayTao?: Date;
NguoiTao_Id?: number;
NgayCapNhat?: Date;
NguoiCapNhat_Id?: number;

}


