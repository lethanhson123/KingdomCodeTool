﻿namespace Data_eHospital_DongNai_A.Model
{
    public partial class CLSKetQua_DienCo : BaseModel
    {
        [Key]
        public int? CLSKetQua_DienCo_Id { get; set; }
public int? CLSKetQua_Id { get; set; }
public int? MauBenh_Id { get; set; }
public int? Col_Int_1 { get; set; }
public int? Col_Int_2 { get; set; }
public int? Col_Int_3 { get; set; }
public int? Col_Int_4 { get; set; }
public int? Col_Int_5 { get; set; }
public int? Col_Int_6 { get; set; }
public int? Col_Int_7 { get; set; }
public int? Col_Int_8 { get; set; }
public int? Col_Int_9 { get; set; }
public int? Col_Int_10 { get; set; }
public string? Col_Text_1 { get; set; }
public string? Col_Text_2 { get; set; }
public string? Col_Text_3 { get; set; }
public string? Col_Text_4 { get; set; }
public string? Col_Text_5 { get; set; }
public string? Col_Text_6 { get; set; }
public string? Col_Text_7 { get; set; }
public string? Col_Text_8 { get; set; }
public string? Col_Text_9 { get; set; }
public string? Col_Text_10 { get; set; }
public DateTime? Col_DateTime_1 { get; set; }
public DateTime? Col_DateTime_2 { get; set; }
public DateTime? Col_DateTime_3 { get; set; }
public DateTime? Col_DateTime_4 { get; set; }
public DateTime? Col_DateTime_5 { get; set; }
public DateTime? Col_DateTime_6 { get; set; }
public DateTime? Col_DateTime_7 { get; set; }
public DateTime? Col_DateTime_8 { get; set; }
public DateTime? Col_DateTime_9 { get; set; }
public DateTime? Col_DateTime_10 { get; set; }
public bool? HienThi { get; set; }
public string? Ma_MauBenh_Column { get; set; }
public int? Idx { get; set; }
public decimal? Col_Decimal_1 { get; set; }
public decimal? Col_Decimal_2 { get; set; }
public decimal? Col_Decimal_3 { get; set; }
public decimal? Col_Decimal_4 { get; set; }
public decimal? Col_Decimal_5 { get; set; }
public decimal? Col_Decimal_6 { get; set; }
public decimal? Col_Decimal_7 { get; set; }
public decimal? Col_Decimal_8 { get; set; }
public decimal? Col_Decimal_9 { get; set; }
public decimal? Col_Decimal_10 { get; set; }
public int? KetQuaMauBenh_Id { get; set; }
public string? TemplateFileName { get; set; }

        public CLSKetQua_DienCo()
        {
        }
    }
}

