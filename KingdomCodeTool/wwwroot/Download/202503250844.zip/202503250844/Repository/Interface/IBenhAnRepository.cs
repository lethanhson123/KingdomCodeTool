﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IBenhAnRepository : IBaseRepository<BenhAn>
    {
    }
    }

