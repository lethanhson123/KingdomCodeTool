﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IHoaDonChiTietRepository : IBaseRepository<HoaDonChiTiet>
    {
    }
    }

