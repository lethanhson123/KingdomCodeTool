﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface INoiTru_NhapVienRepository : IBaseRepository<NoiTru_NhapVien>
    {
    }
    }

