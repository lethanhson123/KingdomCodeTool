﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface ICLSKetQua_SieuAmTimRepository : IBaseRepository<CLSKetQua_SieuAmTim>
    {
    }
    }

