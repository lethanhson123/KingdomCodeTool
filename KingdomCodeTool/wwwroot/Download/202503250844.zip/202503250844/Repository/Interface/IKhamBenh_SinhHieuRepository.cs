﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IKhamBenh_SinhHieuRepository : IBaseRepository<KhamBenh_SinhHieu>
    {
    }
    }

