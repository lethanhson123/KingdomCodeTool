﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface ICLSKetQuaChiTietRepository : IBaseRepository<CLSKetQuaChiTiet>
    {
    }
    }

