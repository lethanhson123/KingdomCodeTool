﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface INoiTru_TraThuocChiTietRepository : IBaseRepository<NoiTru_TraThuocChiTiet>
    {
    }
    }

