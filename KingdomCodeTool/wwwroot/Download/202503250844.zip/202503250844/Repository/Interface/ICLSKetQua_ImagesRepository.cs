﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface ICLSKetQua_ImagesRepository : IBaseRepository<CLSKetQua_Images>
    {
    }
    }

