﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface INoiTru_LuuTruChiTietRepository : IBaseRepository<NoiTru_LuuTruChiTiet>
    {
    }
    }

