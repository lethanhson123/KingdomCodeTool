﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface ICLSKetQuaKhangSinhDoRepository : IBaseRepository<CLSKetQuaKhangSinhDo>
    {
    }
    }

