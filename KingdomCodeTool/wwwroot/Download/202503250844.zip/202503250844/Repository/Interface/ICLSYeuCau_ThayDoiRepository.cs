﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface ICLSYeuCau_ThayDoiRepository : IBaseRepository<CLSYeuCau_ThayDoi>
    {
    }
    }

