﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface INoiTru_TraThuocRepository : IBaseRepository<NoiTru_TraThuoc>
    {
    }
    }

