﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface ICLSYeuCau_PACSRepository : IBaseRepository<CLSYeuCau_PACS>
    {
    }
    }

