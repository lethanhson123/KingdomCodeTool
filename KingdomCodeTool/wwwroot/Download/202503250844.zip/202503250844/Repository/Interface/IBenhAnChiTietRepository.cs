﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IBenhAnChiTietRepository : IBaseRepository<BenhAnChiTiet>
    {
    }
    }

