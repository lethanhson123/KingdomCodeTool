﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface INoiTru_LuuTru_TraceRepository : IBaseRepository<NoiTru_LuuTru_Trace>
    {
    }
    }

