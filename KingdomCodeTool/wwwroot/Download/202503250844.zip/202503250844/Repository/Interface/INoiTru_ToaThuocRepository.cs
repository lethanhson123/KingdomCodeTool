﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface INoiTru_ToaThuocRepository : IBaseRepository<NoiTru_ToaThuoc>
    {
    }
    }

