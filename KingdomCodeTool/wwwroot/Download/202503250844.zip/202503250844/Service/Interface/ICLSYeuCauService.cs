﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface ICLSYeuCauService : IBaseService<CLSYeuCau>
    {
    }
    }

