﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface INoiTru_LuuTruService : IBaseService<NoiTru_LuuTru>
    {
    }
    }

