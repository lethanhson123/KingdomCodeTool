﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface INoiTru_ToaThuocService : IBaseService<NoiTru_ToaThuoc>
    {
    }
    }

