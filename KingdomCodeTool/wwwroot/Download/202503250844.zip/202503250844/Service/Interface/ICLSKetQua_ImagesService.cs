﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface ICLSKetQua_ImagesService : IBaseService<CLSKetQua_Images>
    {
    }
    }

