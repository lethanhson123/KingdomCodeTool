﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface ICLSKetQuaChiTietService : IBaseService<CLSKetQuaChiTiet>
    {
    }
    }

