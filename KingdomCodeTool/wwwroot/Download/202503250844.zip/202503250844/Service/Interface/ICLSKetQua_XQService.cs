﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface ICLSKetQua_XQService : IBaseService<CLSKetQua_XQ>
    {
    }
    }

