﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface INoiTru_LuuTruChiTietService : IBaseService<NoiTru_LuuTruChiTiet>
    {
    }
    }

