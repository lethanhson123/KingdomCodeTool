﻿namespace Repository.Interface
{
    public interface IDM_BenhVienRepository : IBaseRepository<DM_BenhVien>
    {
    }
    }

