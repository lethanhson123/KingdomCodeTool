﻿namespace Repository_eHospital_DongNai_A.Interface
{
    public interface IKhamBenh_ToaThuocRepository : IBaseRepository<KhamBenh_ToaThuoc>
    {
    }
    }

