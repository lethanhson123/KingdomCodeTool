﻿namespace Service_eHospital_DongNai_A.Interface
{
    public interface IKhamBenh_ToaThuocService : IBaseService<KhamBenh_ToaThuoc>
    {
    }
    }

