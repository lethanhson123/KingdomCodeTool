﻿namespace Repository.Interface
{
    public interface ICongViecRepository : IBaseRepository<CongViec>
    {
    }
    }

