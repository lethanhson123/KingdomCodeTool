﻿namespace Repository_eHospital_DongNai_A_Dictionary.Interface
{
    public interface INhanVien_User_MappingRepository : IBaseRepository<NhanVien_User_Mapping>
    {
    }
    }

