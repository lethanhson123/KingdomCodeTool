﻿namespace Service_eHospital_DongNai_A_Dictionary.Interface
{
    public interface INhanVien_User_MappingService : IBaseService<NhanVien_User_Mapping>
    {
    }
    }

