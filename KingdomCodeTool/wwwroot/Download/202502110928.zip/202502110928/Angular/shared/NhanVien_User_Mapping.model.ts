﻿import { Base } from "./Base.model";

export class NhanVien_User_Mapping extends Base{
NhanVien_User_Id?: number;
NhanVien_Id?: number;
User_Id?: number;

}


