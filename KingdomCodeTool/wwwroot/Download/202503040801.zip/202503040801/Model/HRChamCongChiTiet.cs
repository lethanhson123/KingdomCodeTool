﻿namespace Data.Model
{
    public partial class HRChamCongChiTiet : BaseModel
    {
        [Key]
        public long? ID { get; set; }
public long? ParentID { get; set; }
public string? ParentName { get; set; }
public DateTime? CreatedDate { get; set; }
public long? CreatedMembershipID { get; set; }
public DateTime? LastUpdatedDate { get; set; }
public long? LastUpdatedMembershipID { get; set; }
public int? RowVersion { get; set; }
public int? SortOrder { get; set; }
public bool? Active { get; set; }
public string? TypeName { get; set; }
public string? Name { get; set; }
public string? Code { get; set; }
public string? Note { get; set; }
public string? Display { get; set; }
public string? FileName { get; set; }
public string? Description { get; set; }
public string? HTMLContent { get; set; }
public long? DanhMucNgonNguID { get; set; }
public long? DanhMucUngDungID { get; set; }
public string? DanhMucNgonNguName { get; set; }
public string? DanhMucUngDungName { get; set; }
public int? Year { get; set; }
public int? Month { get; set; }
public int? Day { get; set; }
public DateTime? BatDau { get; set; }
public DateTime? KetThuc { get; set; }
public decimal? ChamCong { get; set; }
public long? DanhMucChamCongID { get; set; }
public string? DanhMucChamCongName { get; set; }
public long? DanhMucPhuCapID { get; set; }
public string? DanhMucPhuCapName { get; set; }

        public HRChamCongChiTiet()
        {
        }
    }
}

