﻿namespace Repository.Interface
{
    public interface IHRBangLuongRepository : IBaseRepository<HRBangLuong>
    {
    }
    }

