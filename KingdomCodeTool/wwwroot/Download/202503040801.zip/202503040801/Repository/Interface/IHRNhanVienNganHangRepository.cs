﻿namespace Repository.Interface
{
    public interface IHRNhanVienNganHangRepository : IBaseRepository<HRNhanVienNganHang>
    {
    }
    }

