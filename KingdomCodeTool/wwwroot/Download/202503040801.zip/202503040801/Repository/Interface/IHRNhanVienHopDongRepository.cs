﻿namespace Repository.Interface
{
    public interface IHRNhanVienHopDongRepository : IBaseRepository<HRNhanVienHopDong>
    {
    }
    }

