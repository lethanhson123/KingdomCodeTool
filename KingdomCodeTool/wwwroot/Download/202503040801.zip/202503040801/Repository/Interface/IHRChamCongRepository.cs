﻿namespace Repository.Interface
{
    public interface IHRChamCongRepository : IBaseRepository<HRChamCong>
    {
    }
    }

