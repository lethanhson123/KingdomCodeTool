﻿namespace Repository.Interface
{
    public interface IHRBangLuongChiTietRepository : IBaseRepository<HRBangLuongChiTiet>
    {
    }
    }

