﻿namespace Repository.Interface
{
    public interface IHRLichCongTacChiTietRepository : IBaseRepository<HRLichCongTacChiTiet>
    {
    }
    }

