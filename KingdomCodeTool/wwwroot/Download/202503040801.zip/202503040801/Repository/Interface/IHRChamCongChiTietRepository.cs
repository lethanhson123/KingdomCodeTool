﻿namespace Repository.Interface
{
    public interface IHRChamCongChiTietRepository : IBaseRepository<HRChamCongChiTiet>
    {
    }
    }

