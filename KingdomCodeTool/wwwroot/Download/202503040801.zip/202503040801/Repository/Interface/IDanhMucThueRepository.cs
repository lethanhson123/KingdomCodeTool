﻿namespace Repository.Interface
{
    public interface IDanhMucThueRepository : IBaseRepository<DanhMucThue>
    {
    }
    }

