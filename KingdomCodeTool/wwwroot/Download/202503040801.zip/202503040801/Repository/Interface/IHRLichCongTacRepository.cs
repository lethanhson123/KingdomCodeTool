﻿namespace Repository.Interface
{
    public interface IHRLichCongTacRepository : IBaseRepository<HRLichCongTac>
    {
    }
    }

