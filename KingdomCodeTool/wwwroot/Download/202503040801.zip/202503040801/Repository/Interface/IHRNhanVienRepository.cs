﻿namespace Repository.Interface
{
    public interface IHRNhanVienRepository : IBaseRepository<HRNhanVien>
    {
    }
    }

