﻿namespace Repository.Interface
{
    public interface IDanhMucChamCongRepository : IBaseRepository<DanhMucChamCong>
    {
    }
    }

