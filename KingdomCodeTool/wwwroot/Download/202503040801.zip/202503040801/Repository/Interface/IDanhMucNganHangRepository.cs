﻿namespace Repository.Interface
{
    public interface IDanhMucNganHangRepository : IBaseRepository<DanhMucNganHang>
    {
    }
    }

