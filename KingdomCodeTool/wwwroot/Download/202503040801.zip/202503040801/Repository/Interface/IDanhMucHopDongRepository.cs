﻿namespace Repository.Interface
{
    public interface IDanhMucHopDongRepository : IBaseRepository<DanhMucHopDong>
    {
    }
    }

