﻿namespace Repository.Interface
{
    public interface IHRNhanVienThanhVienRepository : IBaseRepository<HRNhanVienThanhVien>
    {
    }
    }

