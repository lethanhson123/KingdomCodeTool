﻿namespace Repository.Interface
{
    public interface IHRNhanVienPhuCapRepository : IBaseRepository<HRNhanVienPhuCap>
    {
    }
    }

