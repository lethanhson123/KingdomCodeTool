﻿namespace Repository.Interface
{
    public interface IDanhMucLuongCoBanRepository : IBaseRepository<DanhMucLuongCoBan>
    {
    }
    }

