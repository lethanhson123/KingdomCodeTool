﻿namespace Repository.Interface
{
    public interface IDanhMucGiamTruRepository : IBaseRepository<DanhMucGiamTru>
    {
    }
    }

