﻿namespace Repository.Interface
{
    public interface IHRNhanVienBangCapRepository : IBaseRepository<HRNhanVienBangCap>
    {
    }
    }

