﻿namespace Service.Interface
{
    public interface IHRBangLuongChiTietService : IBaseService<HRBangLuongChiTiet>
    {
    }
    }

