﻿namespace Service.Interface
{
    public interface IDanhMucHopDongService : IBaseService<DanhMucHopDong>
    {
    }
    }

