﻿namespace Service.Interface
{
    public interface IDanhMucNganHangService : IBaseService<DanhMucNganHang>
    {
    }
    }

