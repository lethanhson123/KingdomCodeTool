﻿namespace Service.Interface
{
    public interface IHRNhanVienHopDongService : IBaseService<HRNhanVienHopDong>
    {
    }
    }

