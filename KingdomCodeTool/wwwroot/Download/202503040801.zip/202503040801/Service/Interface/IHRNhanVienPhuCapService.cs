﻿namespace Service.Interface
{
    public interface IHRNhanVienPhuCapService : IBaseService<HRNhanVienPhuCap>
    {
    }
    }

