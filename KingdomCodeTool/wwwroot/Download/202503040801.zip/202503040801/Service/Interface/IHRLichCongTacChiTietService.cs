﻿namespace Service.Interface
{
    public interface IHRLichCongTacChiTietService : IBaseService<HRLichCongTacChiTiet>
    {
    }
    }

