﻿namespace Service.Interface
{
    public interface IHRNhanVienService : IBaseService<HRNhanVien>
    {
    }
    }

