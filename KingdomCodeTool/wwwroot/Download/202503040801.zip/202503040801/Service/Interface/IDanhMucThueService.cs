﻿namespace Service.Interface
{
    public interface IDanhMucThueService : IBaseService<DanhMucThue>
    {
    }
    }

