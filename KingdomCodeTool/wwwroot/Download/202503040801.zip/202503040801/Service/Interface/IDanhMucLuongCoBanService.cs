﻿namespace Service.Interface
{
    public interface IDanhMucLuongCoBanService : IBaseService<DanhMucLuongCoBan>
    {
    }
    }

