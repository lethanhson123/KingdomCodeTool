﻿namespace Service.Interface
{
    public interface IHRChamCongService : IBaseService<HRChamCong>
    {
    }
    }

