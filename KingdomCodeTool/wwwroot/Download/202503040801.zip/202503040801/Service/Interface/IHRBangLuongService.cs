﻿namespace Service.Interface
{
    public interface IHRBangLuongService : IBaseService<HRBangLuong>
    {
    }
    }

