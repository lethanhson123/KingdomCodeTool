﻿namespace Service.Interface
{
    public interface IHRChamCongChiTietService : IBaseService<HRChamCongChiTiet>
    {
    }
    }

