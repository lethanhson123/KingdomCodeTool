﻿namespace Service.Interface
{
    public interface IDanhMucChamCongService : IBaseService<DanhMucChamCong>
    {
    }
    }

