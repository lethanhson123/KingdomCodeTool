﻿namespace Service.Interface
{
    public interface IHRNhanVienThanhVienService : IBaseService<HRNhanVienThanhVien>
    {
    }
    }

