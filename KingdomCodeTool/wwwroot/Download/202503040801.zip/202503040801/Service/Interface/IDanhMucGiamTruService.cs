﻿namespace Service.Interface
{
    public interface IDanhMucGiamTruService : IBaseService<DanhMucGiamTru>
    {
    }
    }

