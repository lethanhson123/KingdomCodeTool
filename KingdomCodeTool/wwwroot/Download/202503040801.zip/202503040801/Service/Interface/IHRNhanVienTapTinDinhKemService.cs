﻿namespace Service.Interface
{
    public interface IHRNhanVienTapTinDinhKemService : IBaseService<HRNhanVienTapTinDinhKem>
    {
    }
    }

