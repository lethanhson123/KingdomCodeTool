﻿namespace Service.Interface
{
    public interface IHRNhanVienBangCapService : IBaseService<HRNhanVienBangCap>
    {
    }
    }

