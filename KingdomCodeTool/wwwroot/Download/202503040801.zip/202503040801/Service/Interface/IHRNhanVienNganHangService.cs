﻿namespace Service.Interface
{
    public interface IHRNhanVienNganHangService : IBaseService<HRNhanVienNganHang>
    {
    }
    }

