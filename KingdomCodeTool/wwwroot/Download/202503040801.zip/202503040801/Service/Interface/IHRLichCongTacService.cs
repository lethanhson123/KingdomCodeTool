﻿namespace Service.Interface
{
    public interface IHRLichCongTacService : IBaseService<HRLichCongTac>
    {
    }
    }

