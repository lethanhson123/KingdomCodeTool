﻿namespace Data.Model
{
    public partial class Company : BaseModel
    {
        public Company()
        {
        }
    }
}

