﻿namespace Business.Interface
{
    public interface ICompanyService : IBaseService<Company>
    {
    }
    }

