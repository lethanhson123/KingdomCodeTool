﻿namespace Data.Repository.Interface
{
    public interface ICompanyRepository : IBaseRepository<Company>
    {
    }
    }

