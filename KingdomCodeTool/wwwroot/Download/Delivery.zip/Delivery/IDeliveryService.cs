﻿namespace Business.Interface
{
    public interface IDeliveryService : IBaseService<Delivery>
    {
    }
    }

