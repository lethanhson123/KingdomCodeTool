﻿namespace Data.Model
{
    public partial class Delivery : BaseModel
    {
        public Delivery()
        {
        }
    }
}

