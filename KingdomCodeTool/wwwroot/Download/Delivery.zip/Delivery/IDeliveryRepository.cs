﻿namespace Data.Repository.Interface
{
    public interface IDeliveryRepository : IBaseRepository<Delivery>
    {
    }
    }

