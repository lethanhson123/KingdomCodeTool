﻿namespace Service.Interface
{
    public interface IDM_DonViHanhChinhService : IBaseService<DM_DonViHanhChinh>
    {
    }
    }

