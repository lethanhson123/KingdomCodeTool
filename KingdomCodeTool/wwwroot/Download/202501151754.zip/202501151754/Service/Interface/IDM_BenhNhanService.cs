﻿namespace Service.Interface
{
    public interface IDM_BenhNhanService : IBaseService<DM_BenhNhan>
    {
    }
    }

