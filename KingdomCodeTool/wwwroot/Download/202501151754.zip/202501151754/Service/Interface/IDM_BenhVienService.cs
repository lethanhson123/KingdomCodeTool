﻿namespace Service.Interface
{
    public interface IDM_BenhVienService : IBaseService<DM_BenhVien>
    {
    }
    }

