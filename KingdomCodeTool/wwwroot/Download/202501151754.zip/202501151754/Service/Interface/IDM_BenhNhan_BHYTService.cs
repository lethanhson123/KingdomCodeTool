﻿namespace Service.Interface
{
    public interface IDM_BenhNhan_BHYTService : IBaseService<DM_BenhNhan_BHYT>
    {
    }
    }

