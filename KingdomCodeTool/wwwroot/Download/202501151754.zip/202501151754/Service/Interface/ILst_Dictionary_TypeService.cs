﻿namespace Service.Interface
{
    public interface ILst_Dictionary_TypeService : IBaseService<Lst_Dictionary_Type>
    {
    }
    }

