﻿namespace Repository.Interface
{
    public interface ILst_Dictionary_TypeRepository : IBaseRepository<Lst_Dictionary_Type>
    {
    }
    }

