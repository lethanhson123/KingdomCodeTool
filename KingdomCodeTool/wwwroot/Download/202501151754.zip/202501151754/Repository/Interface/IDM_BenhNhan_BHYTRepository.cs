﻿namespace Repository.Interface
{
    public interface IDM_BenhNhan_BHYTRepository : IBaseRepository<DM_BenhNhan_BHYT>
    {
    }
    }

