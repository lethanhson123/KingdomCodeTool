﻿namespace Repository.Interface
{
    public interface IDM_DonViHanhChinhRepository : IBaseRepository<DM_DonViHanhChinh>
    {
    }
    }

