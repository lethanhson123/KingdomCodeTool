﻿namespace Repository.Interface
{
    public interface IDM_BenhNhanRepository : IBaseRepository<DM_BenhNhan>
    {
    }
    }

