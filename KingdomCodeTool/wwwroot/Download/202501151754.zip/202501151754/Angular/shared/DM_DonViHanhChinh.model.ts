﻿import { Base } from "./Base.model";

export class DM_DonViHanhChinh extends Base{
DonViHanhChinh_Id?: number;
MaDonVi?: string;
TenDonVi?: string;
CapDonVi?: number;
CapTren_Id?: number;
MaVung_Id?: number;
KhuVucLuuTru_Id?: number;
TamNgung?: boolean;
TenTat?: string;
TenTat_2?: string;
TenTat_3?: string;
TenKhongDau?: string;
NgayTao?: Date;
NguoiTao_Id?: number;
NgayCapNhat?: Date;
NguoiCapNhat_Id?: number;
SiteCode?: string;
Mapping_Public_Id?: number;
MaDonVi_HSSK?: string;

}


