﻿import { Base } from "./Base.model";

export class DM_BenhNhan_BHYT extends Base{
BenhNhan_BHYT_Id?: number;
BenhNhan_Id?: number;
LoaiBHYT?: number;
SoThe?: string;
NgayCap?: Date;
NgayHieuLuc?: Date;
NgayHetHieuLuc?: Date;
TinhThanh_CapThe_Id?: number;
BenhVien_KCB_Id?: number;
TamNgung?: boolean;
NgayTao?: Date;
NguoiTao_Id?: number;
NgayCapNhat?: Date;
NguoiCapNhat_Id?: number;
Tren3Nam?: boolean;
Tren6Thang?: boolean;
NgayHuong5Nam?: Date;

}


